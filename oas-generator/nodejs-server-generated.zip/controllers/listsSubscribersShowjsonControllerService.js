'use strict'

module.exports.listsSubscribersShow = function listsSubscribersShow(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscribersShow'
  });
};

module.exports.listsSubscribersShowJsonPARAMETERS = function listsSubscribersShowJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscribersShowJsonPARAMETERS'
  });
};