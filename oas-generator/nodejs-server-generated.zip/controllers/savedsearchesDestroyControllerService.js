'use strict'

module.exports.saved_searchesDestroyIdJsonPARAMETERS = function saved_searchesDestroyIdJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesDestroyIdJsonPARAMETERS'
  });
};

module.exports.saved_searchesDestroy = function saved_searchesDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesDestroy'
  });
};