'use strict'

module.exports.listsStatuses = function listsStatuses(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsStatuses'
  });
};

module.exports.listsStatusesJsonPARAMETERS = function listsStatusesJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsStatusesJsonPARAMETERS'
  });
};