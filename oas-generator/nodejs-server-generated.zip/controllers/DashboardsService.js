'use strict'

module.exports.allDashboards = function allDashboards(req, res, next) {
  res.send({
    message: 'This is the raw controller for allDashboards'
  });
};

module.exports.createDashboard = function createDashboard(req, res, next) {
  res.send({
    message: 'This is the raw controller for createDashboard'
  });
};

module.exports.destroyDashboard = function destroyDashboard(req, res, next) {
  res.send({
    message: 'This is the raw controller for destroyDashboard'
  });
};

module.exports.getDashboard = function getDashboard(req, res, next) {
  res.send({
    message: 'This is the raw controller for getDashboard'
  });
};

module.exports.updateDashboard = function updateDashboard(req, res, next) {
  res.send({
    message: 'This is the raw controller for updateDashboard'
  });
};

module.exports.replaceDashboard = function replaceDashboard(req, res, next) {
  res.send({
    message: 'This is the raw controller for replaceDashboard'
  });
};