'use strict'

module.exports.favoritesCreateJsonPARAMETERS = function favoritesCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for favoritesCreateJsonPARAMETERS'
  });
};

module.exports.favoritesCreate = function favoritesCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for favoritesCreate'
  });
};