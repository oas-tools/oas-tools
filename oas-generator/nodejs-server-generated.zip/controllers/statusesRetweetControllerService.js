'use strict'

module.exports.statusesRetweetIdJsonPARAMETERS = function statusesRetweetIdJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesRetweetIdJsonPARAMETERS'
  });
};

module.exports.statusesretweetid = function statusesretweetid(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesretweetid'
  });
};