'use strict'

module.exports.friendshipsOutgoing = function friendshipsOutgoing(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsOutgoing'
  });
};

module.exports.friendshipsOutgoingJsonPARAMETERS = function friendshipsOutgoingJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsOutgoingJsonPARAMETERS'
  });
};