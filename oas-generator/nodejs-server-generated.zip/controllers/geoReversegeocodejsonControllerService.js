'use strict'

module.exports.geoReverse_geocode = function geoReverse_geocode(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoReverse_geocode'
  });
};

module.exports.geoReverse_geocodeJsonPARAMETERS = function geoReverse_geocodeJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoReverse_geocodeJsonPARAMETERS'
  });
};