'use strict'

module.exports.geoSearch = function geoSearch(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoSearch'
  });
};

module.exports.geoSearchJsonPARAMETERS = function geoSearchJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoSearchJsonPARAMETERS'
  });
};