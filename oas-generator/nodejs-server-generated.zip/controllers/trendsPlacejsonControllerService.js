'use strict'

module.exports.trendsPlace = function trendsPlace(req, res, next) {
  res.send({
    message: 'This is the raw controller for trendsPlace'
  });
};

module.exports.trendsPlaceJsonPARAMETERS = function trendsPlaceJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for trendsPlaceJsonPARAMETERS'
  });
};