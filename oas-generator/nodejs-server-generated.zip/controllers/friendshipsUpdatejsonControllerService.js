'use strict'

module.exports.friendshipsUpdateJsonPARAMETERS = function friendshipsUpdateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsUpdateJsonPARAMETERS'
  });
};

module.exports.friendshipsUpdate = function friendshipsUpdate(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsUpdate'
  });
};