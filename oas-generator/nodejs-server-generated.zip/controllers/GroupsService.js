'use strict'

module.exports.allGroups = function allGroups(req, res, next) {
  res.send({
    message: 'This is the raw controller for allGroups'
  });
};

module.exports.createGroup = function createGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for createGroup'
  });
};

module.exports.destroyGroup = function destroyGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for destroyGroup'
  });
};

module.exports.getGroup = function getGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for getGroup'
  });
};

module.exports.updateGroup = function updateGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for updateGroup'
  });
};

module.exports.replaceGroup = function replaceGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for replaceGroup'
  });
};

module.exports.addFeedToGroup = function addFeedToGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for addFeedToGroup'
  });
};

module.exports.removeFeedFromGroup = function removeFeedFromGroup(req, res, next) {
  res.send({
    message: 'This is the raw controller for removeFeedFromGroup'
  });
};