'use strict'

module.exports.accountSettingsGet = function accountSettingsGet(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountSettingsGet'
  });
};

module.exports.accountSettingsJsonPARAMETERS = function accountSettingsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountSettingsJsonPARAMETERS'
  });
};

module.exports.accountSettingsPost = function accountSettingsPost(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountSettingsPost'
  });
};