'use strict'

var accountUpdateprofilebackgroundimagejsonController = require('./accountUpdateprofilebackgroundimagejsonControllerService');

module.exports.accountUpdate_profile_background_imageJsonPARAMETERS = function accountUpdate_profile_background_imageJsonPARAMETERS(req, res, next) {
  accountUpdateprofilebackgroundimagejsonController.accountUpdate_profile_background_imageJsonPARAMETERS(req.swagger.params, res, next);
};

module.exports.accountsUpdate_profile_background_image = function accountsUpdate_profile_background_image(req, res, next) {
  accountUpdateprofilebackgroundimagejsonController.accountsUpdate_profile_background_image(req.swagger.params, res, next);
};