'use strict'

module.exports.followersIds = function followersIds(req, res, next) {
  res.send({
    message: 'This is the raw controller for followersIds'
  });
};

module.exports.followersIdsJsonPARAMETERS = function followersIdsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for followersIdsJsonPARAMETERS'
  });
};