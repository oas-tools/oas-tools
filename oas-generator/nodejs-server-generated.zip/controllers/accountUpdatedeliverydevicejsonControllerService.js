'use strict'

module.exports.accountUpdate_delivery_deviceJsonPARAMETERS = function accountUpdate_delivery_deviceJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountUpdate_delivery_deviceJsonPARAMETERS'
  });
};

module.exports.accountUpdate_delivery_device = function accountUpdate_delivery_device(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountUpdate_delivery_device'
  });
};