'use strict'

module.exports.listsMemberships = function listsMemberships(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMemberships'
  });
};

module.exports.listsMembershipsJsonPARAMETERS = function listsMembershipsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembershipsJsonPARAMETERS'
  });
};