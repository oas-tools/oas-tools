'use strict'

module.exports.trendsClosest = function trendsClosest(req, res, next) {
  res.send({
    message: 'This is the raw controller for trendsClosest'
  });
};

module.exports.trendsClosestJsonPARAMETERS = function trendsClosestJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for trendsClosestJsonPARAMETERS'
  });
};