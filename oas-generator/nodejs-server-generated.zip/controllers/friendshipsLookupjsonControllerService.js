'use strict'

module.exports.friendshipsLookup = function friendshipsLookup(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsLookup'
  });
};

module.exports.friendshipsLookupJsonPARAMETERS = function friendshipsLookupJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsLookupJsonPARAMETERS'
  });
};