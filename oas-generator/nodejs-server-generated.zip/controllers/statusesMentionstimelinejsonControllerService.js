'use strict'

module.exports.statusesMentionsTimeline = function statusesMentionsTimeline(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesMentionsTimeline'
  });
};

module.exports.statusesMentions_timelineJsonPARAMETERS = function statusesMentions_timelineJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesMentions_timelineJsonPARAMETERS'
  });
};