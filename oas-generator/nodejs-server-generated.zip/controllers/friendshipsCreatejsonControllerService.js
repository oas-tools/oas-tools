'use strict'

module.exports.friendshipsCreateJsonPARAMETERS = function friendshipsCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsCreateJsonPARAMETERS'
  });
};

module.exports.friendshipsCreate = function friendshipsCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsCreate'
  });
};