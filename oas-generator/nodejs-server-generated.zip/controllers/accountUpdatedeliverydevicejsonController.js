'use strict'

var accountUpdatedeliverydevicejsonController = require('./accountUpdatedeliverydevicejsonControllerService');

module.exports.accountUpdate_delivery_deviceJsonPARAMETERS = function accountUpdate_delivery_deviceJsonPARAMETERS(req, res, next) {
  accountUpdatedeliverydevicejsonController.accountUpdate_delivery_deviceJsonPARAMETERS(req.swagger.params, res, next);
};

module.exports.accountUpdate_delivery_device = function accountUpdate_delivery_device(req, res, next) {
  accountUpdatedeliverydevicejsonController.accountUpdate_delivery_device(req.swagger.params, res, next);
};