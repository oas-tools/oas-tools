'use strict'

module.exports.productsGET = function productsGET(req, res, next) {
  res.send({
    message: 'This is the raw controller for productsGET'
  });
};