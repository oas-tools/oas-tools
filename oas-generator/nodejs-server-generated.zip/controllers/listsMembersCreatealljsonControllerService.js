'use strict'

module.exports.listsMembersCreate_allJsonPARAMETERS = function listsMembersCreate_allJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersCreate_allJsonPARAMETERS'
  });
};

module.exports.listsMembersCreate_all = function listsMembersCreate_all(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersCreate_all'
  });
};