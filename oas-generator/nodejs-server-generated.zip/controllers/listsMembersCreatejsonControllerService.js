'use strict'

module.exports.listsMembersCreateJsonPARAMETERS = function listsMembersCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersCreateJsonPARAMETERS'
  });
};

module.exports.listsMembersCreate = function listsMembersCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersCreate'
  });
};