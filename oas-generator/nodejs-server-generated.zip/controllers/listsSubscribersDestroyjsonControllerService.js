'use strict'

module.exports.listsSubscribersDestroyJsonPARAMETERS = function listsSubscribersDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscribersDestroyJsonPARAMETERS'
  });
};

module.exports.listsSubscribersDestroy = function listsSubscribersDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscribersDestroy'
  });
};