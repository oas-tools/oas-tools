'use strict'

module.exports.saved_searchesCreateJsonPARAMETERS = function saved_searchesCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesCreateJsonPARAMETERS'
  });
};

module.exports.saved_searchesCreate = function saved_searchesCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesCreate'
  });
};