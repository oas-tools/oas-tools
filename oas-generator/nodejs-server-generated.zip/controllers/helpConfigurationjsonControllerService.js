'use strict'

module.exports.helpConfigurations = function helpConfigurations(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpConfigurations'
  });
};

module.exports.helpConfigurationJsonPARAMETERS = function helpConfigurationJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpConfigurationJsonPARAMETERS'
  });
};