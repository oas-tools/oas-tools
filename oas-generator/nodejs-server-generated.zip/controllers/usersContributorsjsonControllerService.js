'use strict'

module.exports.usersContributors = function usersContributors(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersContributors'
  });
};

module.exports.usersContributorsJsonPARAMETERS = function usersContributorsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersContributorsJsonPARAMETERS'
  });
};