'use strict'

module.exports.listsMembers = function listsMembers(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembers'
  });
};

module.exports.listsMembersJsonPARAMETERS = function listsMembersJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersJsonPARAMETERS'
  });
};