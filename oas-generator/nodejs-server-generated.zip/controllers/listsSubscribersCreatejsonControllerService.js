'use strict'

module.exports.listsSubscribersCreateJsonPARAMETERS = function listsSubscribersCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscribersCreateJsonPARAMETERS'
  });
};

module.exports.listsSubscribersCreate = function listsSubscribersCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscribersCreate'
  });
};