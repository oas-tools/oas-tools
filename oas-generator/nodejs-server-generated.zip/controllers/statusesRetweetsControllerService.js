'use strict'

module.exports.statusesRetweets = function statusesRetweets(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesRetweets'
  });
};

module.exports.statusesRetweetsIdJsonPARAMETERS = function statusesRetweetsIdJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesRetweetsIdJsonPARAMETERS'
  });
};