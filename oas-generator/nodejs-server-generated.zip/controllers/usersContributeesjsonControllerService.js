'use strict'

module.exports.usersContributees = function usersContributees(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersContributees'
  });
};

module.exports.usersContributeesJsonPARAMETERS = function usersContributeesJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersContributeesJsonPARAMETERS'
  });
};