'use strict'

module.exports.geoPlace_id = function geoPlace_id(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoPlace_id'
  });
};

module.exports.geoIdPlace_idJsonPARAMETERS = function geoIdPlace_idJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoIdPlace_idJsonPARAMETERS'
  });
};