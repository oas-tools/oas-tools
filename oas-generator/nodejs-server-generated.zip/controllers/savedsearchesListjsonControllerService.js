'use strict'

module.exports.saved_searchesList = function saved_searchesList(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesList'
  });
};

module.exports.saved_searchesListJsonPARAMETERS = function saved_searchesListJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesListJsonPARAMETERS'
  });
};