'use strict'

module.exports.helpTos = function helpTos(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpTos'
  });
};

module.exports.helpTosJsonPARAMETERS = function helpTosJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpTosJsonPARAMETERS'
  });
};