'use strict'

module.exports.direct_messagesDestroyJsonPARAMETERS = function direct_messagesDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for direct_messagesDestroyJsonPARAMETERS'
  });
};

module.exports.direct_messagesDestroy = function direct_messagesDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for direct_messagesDestroy'
  });
};