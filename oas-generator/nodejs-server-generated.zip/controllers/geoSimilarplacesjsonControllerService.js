'use strict'

module.exports.geoSimilar_places = function geoSimilar_places(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoSimilar_places'
  });
};

module.exports.geoSimilar_placesJsonPARAMETERS = function geoSimilar_placesJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for geoSimilar_placesJsonPARAMETERS'
  });
};