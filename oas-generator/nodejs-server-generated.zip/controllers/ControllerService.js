'use strict'

module.exports.listDataSets = function listDataSets(req, res, next) {
  res.send({
    message: 'This is the raw controller for listDataSets'
  });
};