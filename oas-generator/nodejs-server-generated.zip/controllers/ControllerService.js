'use strict'

module.exports.undefined = function undefined(req, res, next) {
  res.send({
    message: 'This is the raw controller for undefined'
  });
};