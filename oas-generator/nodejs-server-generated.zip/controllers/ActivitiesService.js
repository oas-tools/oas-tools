'use strict'

module.exports.destroyActivities = function destroyActivities(req, res, next) {
  res.send({
    message: 'This is the raw controller for destroyActivities'
  });
};

module.exports.allActivities = function allActivities(req, res, next) {
  res.send({
    message: 'This is the raw controller for allActivities'
  });
};

module.exports.getActivity = function getActivity(req, res, next) {
  res.send({
    message: 'This is the raw controller for getActivity'
  });
};