'use strict'

module.exports.usersSearch = function usersSearch(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSearch'
  });
};

module.exports.usersSearchJsonPARAMETERS = function usersSearchJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSearchJsonPARAMETERS'
  });
};