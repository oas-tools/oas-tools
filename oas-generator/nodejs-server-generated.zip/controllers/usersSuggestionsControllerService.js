'use strict'

module.exports.usersSuggestionsSlug = function usersSuggestionsSlug(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSuggestionsSlug'
  });
};

module.exports.usersSuggestionsSlugJsonPARAMETERS = function usersSuggestionsSlugJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSuggestionsSlugJsonPARAMETERS'
  });
};