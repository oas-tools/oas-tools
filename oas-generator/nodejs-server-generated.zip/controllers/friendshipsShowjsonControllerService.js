'use strict'

module.exports.friendshipsShow = function friendshipsShow(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsShow'
  });
};

module.exports.friendshipsShowJsonPARAMETERS = function friendshipsShowJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsShowJsonPARAMETERS'
  });
};