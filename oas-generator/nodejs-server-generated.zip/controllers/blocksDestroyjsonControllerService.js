'use strict'

module.exports.blocksDestroyJsonPARAMETERS = function blocksDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for blocksDestroyJsonPARAMETERS'
  });
};

module.exports.blocksDestroy = function blocksDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for blocksDestroy'
  });
};