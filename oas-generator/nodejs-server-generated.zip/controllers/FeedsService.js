'use strict'

module.exports.allFeeds = function allFeeds(req, res, next) {
  res.send({
    message: 'This is the raw controller for allFeeds'
  });
};

module.exports.createFeed = function createFeed(req, res, next) {
  res.send({
    message: 'This is the raw controller for createFeed'
  });
};

module.exports.destroyFeed = function destroyFeed(req, res, next) {
  res.send({
    message: 'This is the raw controller for destroyFeed'
  });
};

module.exports.getFeed = function getFeed(req, res, next) {
  res.send({
    message: 'This is the raw controller for getFeed'
  });
};

module.exports.updateFeed = function updateFeed(req, res, next) {
  res.send({
    message: 'This is the raw controller for updateFeed'
  });
};

module.exports.replaceFeed = function replaceFeed(req, res, next) {
  res.send({
    message: 'This is the raw controller for replaceFeed'
  });
};

module.exports.getFeedDetails = function getFeedDetails(req, res, next) {
  res.send({
    message: 'This is the raw controller for getFeedDetails'
  });
};