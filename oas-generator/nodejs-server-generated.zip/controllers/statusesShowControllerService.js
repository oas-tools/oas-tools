'use strict'

module.exports.statusesShow = function statusesShow(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesShow'
  });
};

module.exports.statusesShowIdJsonPARAMETERS = function statusesShowIdJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesShowIdJsonPARAMETERS'
  });
};