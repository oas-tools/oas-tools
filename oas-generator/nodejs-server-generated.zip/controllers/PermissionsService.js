'use strict'

module.exports.allPermissions = function allPermissions(req, res, next) {
  res.send({
    message: 'This is the raw controller for allPermissions'
  });
};

module.exports.createPermission = function createPermission(req, res, next) {
  res.send({
    message: 'This is the raw controller for createPermission'
  });
};

module.exports.destroyPermission = function destroyPermission(req, res, next) {
  res.send({
    message: 'This is the raw controller for destroyPermission'
  });
};

module.exports.getPermission = function getPermission(req, res, next) {
  res.send({
    message: 'This is the raw controller for getPermission'
  });
};

module.exports.updatePermission = function updatePermission(req, res, next) {
  res.send({
    message: 'This is the raw controller for updatePermission'
  });
};

module.exports.replacePermission = function replacePermission(req, res, next) {
  res.send({
    message: 'This is the raw controller for replacePermission'
  });
};