'use strict'

module.exports.estimatesPriceGET = function estimatesPriceGET(req, res, next) {
  res.send({
    message: 'This is the raw controller for estimatesPriceGET'
  });
};