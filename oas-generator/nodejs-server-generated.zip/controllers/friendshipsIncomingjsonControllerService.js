'use strict'

module.exports.friendshipsIncoming = function friendshipsIncoming(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsIncoming'
  });
};

module.exports.friendshipsIncomingJsonPARAMETERS = function friendshipsIncomingJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsIncomingJsonPARAMETERS'
  });
};