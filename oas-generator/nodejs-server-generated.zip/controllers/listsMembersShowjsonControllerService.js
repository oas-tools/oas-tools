'use strict'

module.exports.listsMembersShow = function listsMembersShow(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersShow'
  });
};

module.exports.listsMembersShowJsonPARAMETERS = function listsMembersShowJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersShowJsonPARAMETERS'
  });
};