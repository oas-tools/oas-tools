'use strict'

module.exports.applicationRate_limit_status = function applicationRate_limit_status(req, res, next) {
  res.send({
    message: 'This is the raw controller for applicationRate_limit_status'
  });
};

module.exports.applicationRate_limit_statusJsonPARAMETERS = function applicationRate_limit_statusJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for applicationRate_limit_statusJsonPARAMETERS'
  });
};