'use strict'

module.exports.blocksIds = function blocksIds(req, res, next) {
  res.send({
    message: 'This is the raw controller for blocksIds'
  });
};

module.exports.blocksIdsJsonPARAMETERS = function blocksIdsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for blocksIdsJsonPARAMETERS'
  });
};