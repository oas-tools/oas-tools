'use strict'

module.exports.listsMembersDestroyJsonPARAMETERS = function listsMembersDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersDestroyJsonPARAMETERS'
  });
};

module.exports.listsMembersDestroy = function listsMembersDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersDestroy'
  });
};