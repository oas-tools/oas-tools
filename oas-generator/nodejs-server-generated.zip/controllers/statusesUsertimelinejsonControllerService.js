'use strict'

module.exports.statusesUser_timeline = function statusesUser_timeline(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesUser_timeline'
  });
};

module.exports.statusesUser_timelineJsonPARAMETERS = function statusesUser_timelineJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesUser_timelineJsonPARAMETERS'
  });
};