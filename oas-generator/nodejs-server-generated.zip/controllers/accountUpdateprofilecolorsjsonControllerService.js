'use strict'

module.exports.accountUpdate_profile_colorsJsonPARAMETERS = function accountUpdate_profile_colorsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountUpdate_profile_colorsJsonPARAMETERS'
  });
};

module.exports.accountsUpdate_profile_colors = function accountsUpdate_profile_colors(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountsUpdate_profile_colors'
  });
};