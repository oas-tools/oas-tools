module.exports.performSearch = function performSearch(req, res, next) {
  res.send({
    message: 'This is the raw controller for performSearch'
  });
};