module.exports.undefined = function undefined(req, res, next) {
  {
    dataset
  }
  Controller.undefined(req.swagger.params, res, next);
};

module.exports.undefined = function undefined(req, res, next) {
  {
    dataset
  }
  Controller.undefined(req.swagger.params, res, next);
};