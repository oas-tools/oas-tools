'use strict'

module.exports.statusesHome_timeline = function statusesHome_timeline(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesHome_timeline'
  });
};

module.exports.statusesHome_timelineJsonPARAMETERS = function statusesHome_timelineJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesHome_timelineJsonPARAMETERS'
  });
};