'use strict'

module.exports.listsSubscriptions = function listsSubscriptions(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscriptions'
  });
};

module.exports.listsSubscriptionsJsonPARAMETERS = function listsSubscriptionsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsSubscriptionsJsonPARAMETERS'
  });
};