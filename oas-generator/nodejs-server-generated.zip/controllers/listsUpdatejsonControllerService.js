'use strict'

module.exports.listsUpdateJsonPARAMETERS = function listsUpdateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsUpdateJsonPARAMETERS'
  });
};

module.exports.listsUpdate = function listsUpdate(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsUpdate'
  });
};