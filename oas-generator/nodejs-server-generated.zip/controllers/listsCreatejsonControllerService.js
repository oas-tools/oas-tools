'use strict'

module.exports.listsCreateJsonPARAMETERS = function listsCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsCreateJsonPARAMETERS'
  });
};

module.exports.listsCreate = function listsCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsCreate'
  });
};