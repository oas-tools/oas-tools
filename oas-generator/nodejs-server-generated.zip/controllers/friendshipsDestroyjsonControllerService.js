'use strict'

module.exports.friendshipsDestroyJsonPARAMETERS = function friendshipsDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsDestroyJsonPARAMETERS'
  });
};

module.exports.friendshipsDestroy = function friendshipsDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for friendshipsDestroy'
  });
};