'use strict'

module.exports.usersSuggestionsslugmembers = function usersSuggestionsslugmembers(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSuggestionsslugmembers'
  });
};

module.exports.usersSuggestionsSlugMembersJsonPARAMETERS = function usersSuggestionsSlugMembersJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSuggestionsSlugMembersJsonPARAMETERS'
  });
};