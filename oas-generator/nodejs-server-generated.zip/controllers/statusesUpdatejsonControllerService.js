'use strict'

module.exports.statusesUpdateJsonPARAMETERS = function statusesUpdateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesUpdateJsonPARAMETERS'
  });
};

module.exports.statusesUpdate = function statusesUpdate(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesUpdate'
  });
};