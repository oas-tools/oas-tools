'use strict'

module.exports.statusesDestroyIdJsonPARAMETERS = function statusesDestroyIdJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesDestroyIdJsonPARAMETERS'
  });
};

module.exports.statusesDestroy = function statusesDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesDestroy'
  });
};