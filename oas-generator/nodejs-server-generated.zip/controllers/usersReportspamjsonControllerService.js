'use strict'

module.exports.usersReport_spamJsonPARAMETERS = function usersReport_spamJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersReport_spamJsonPARAMETERS'
  });
};

module.exports.usersReport_spam = function usersReport_spam(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersReport_spam'
  });
};