'use strict'

module.exports.direct_messagesNewJsonPARAMETERS = function direct_messagesNewJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for direct_messagesNewJsonPARAMETERS'
  });
};

module.exports.direct_messagesNew = function direct_messagesNew(req, res, next) {
  res.send({
    message: 'This is the raw controller for direct_messagesNew'
  });
};