'use strict'

module.exports.favoritesDestroyJsonPARAMETERS = function favoritesDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for favoritesDestroyJsonPARAMETERS'
  });
};

module.exports.favoritesDestroy = function favoritesDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for favoritesDestroy'
  });
};