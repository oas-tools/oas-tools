'use strict'

module.exports.listsDestroyJsonPARAMETERS = function listsDestroyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsDestroyJsonPARAMETERS'
  });
};

module.exports.listsDestroy = function listsDestroy(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsDestroy'
  });
};