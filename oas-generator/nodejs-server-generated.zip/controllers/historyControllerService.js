'use strict'

module.exports.historyGET = function historyGET(req, res, next) {
  res.send({
    message: 'This is the raw controller for historyGET'
  });
};