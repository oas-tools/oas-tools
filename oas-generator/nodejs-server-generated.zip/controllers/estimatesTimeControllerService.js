'use strict'

module.exports.estimatesTimeGET = function estimatesTimeGET(req, res, next) {
  res.send({
    message: 'This is the raw controller for estimatesTimeGET'
  });
};