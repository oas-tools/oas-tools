module.exports.listSearchableFields = function listSearchableFields(req, res, next) {
  res.send({
    message: 'This is the raw controller for listSearchableFields'
  });
};