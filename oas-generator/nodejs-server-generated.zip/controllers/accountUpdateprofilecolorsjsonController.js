'use strict'

var accountUpdateprofilecolorsjsonController = require('./accountUpdateprofilecolorsjsonControllerService');

module.exports.accountUpdate_profile_colorsJsonPARAMETERS = function accountUpdate_profile_colorsJsonPARAMETERS(req, res, next) {
  accountUpdateprofilecolorsjsonController.accountUpdate_profile_colorsJsonPARAMETERS(req.swagger.params, res, next);
};

module.exports.accountsUpdate_profile_colors = function accountsUpdate_profile_colors(req, res, next) {
  accountUpdateprofilecolorsjsonController.accountsUpdate_profile_colors(req.swagger.params, res, next);
};