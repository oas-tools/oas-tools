'use strict'

module.exports.helpLanguages = function helpLanguages(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpLanguages'
  });
};

module.exports.helpLanguagesJsonPARAMETERS = function helpLanguagesJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpLanguagesJsonPARAMETERS'
  });
};