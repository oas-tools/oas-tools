'use strict'

module.exports.savedsearchesid = function savedsearchesid(req, res, next) {
  res.send({
    message: 'This is the raw controller for savedsearchesid'
  });
};

module.exports.saved_searchesShowIdJsonPARAMETERS = function saved_searchesShowIdJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for saved_searchesShowIdJsonPARAMETERS'
  });
};