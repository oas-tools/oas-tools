'use strict'

module.exports.accountUpdate_profileJsonPARAMETERS = function accountUpdate_profileJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountUpdate_profileJsonPARAMETERS'
  });
};

module.exports.accountUpdate_profile = function accountUpdate_profile(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountUpdate_profile'
  });
};