'use strict'

module.exports.accountUpdate_profile_imageJsonPARAMETERS = function accountUpdate_profile_imageJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountUpdate_profile_imageJsonPARAMETERS'
  });
};

module.exports.accountsUpdate_profile_image = function accountsUpdate_profile_image(req, res, next) {
  res.send({
    message: 'This is the raw controller for accountsUpdate_profile_image'
  });
};