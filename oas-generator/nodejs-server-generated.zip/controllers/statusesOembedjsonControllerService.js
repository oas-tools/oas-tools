'use strict'

module.exports.statusesOembed = function statusesOembed(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesOembed'
  });
};

module.exports.statusesOembedJsonPARAMETERS = function statusesOembedJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesOembedJsonPARAMETERS'
  });
};