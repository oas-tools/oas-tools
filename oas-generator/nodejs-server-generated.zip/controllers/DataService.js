'use strict'

module.exports.allData = function allData(req, res, next) {
  res.send({
    message: 'This is the raw controller for allData'
  });
};

module.exports.createData = function createData(req, res, next) {
  res.send({
    message: 'This is the raw controller for createData'
  });
};

module.exports.batchCreateData = function batchCreateData(req, res, next) {
  res.send({
    message: 'This is the raw controller for batchCreateData'
  });
};

module.exports.chartData = function chartData(req, res, next) {
  res.send({
    message: 'This is the raw controller for chartData'
  });
};

module.exports.firstData = function firstData(req, res, next) {
  res.send({
    message: 'This is the raw controller for firstData'
  });
};

module.exports.lastData = function lastData(req, res, next) {
  res.send({
    message: 'This is the raw controller for lastData'
  });
};

module.exports.nextData = function nextData(req, res, next) {
  res.send({
    message: 'This is the raw controller for nextData'
  });
};

module.exports.previousData = function previousData(req, res, next) {
  res.send({
    message: 'This is the raw controller for previousData'
  });
};

module.exports.retainData = function retainData(req, res, next) {
  res.send({
    message: 'This is the raw controller for retainData'
  });
};

module.exports.destroyData = function destroyData(req, res, next) {
  res.send({
    message: 'This is the raw controller for destroyData'
  });
};

module.exports.getData = function getData(req, res, next) {
  res.send({
    message: 'This is the raw controller for getData'
  });
};

module.exports.updateData = function updateData(req, res, next) {
  res.send({
    message: 'This is the raw controller for updateData'
  });
};

module.exports.replaceData = function replaceData(req, res, next) {
  res.send({
    message: 'This is the raw controller for replaceData'
  });
};

module.exports.createGroupData = function createGroupData(req, res, next) {
  res.send({
    message: 'This is the raw controller for createGroupData'
  });
};

module.exports.allGroupFeedData = function allGroupFeedData(req, res, next) {
  res.send({
    message: 'This is the raw controller for allGroupFeedData'
  });
};

module.exports.createGroupFeedData = function createGroupFeedData(req, res, next) {
  res.send({
    message: 'This is the raw controller for createGroupFeedData'
  });
};

module.exports.batchCreateGroupFeedData = function batchCreateGroupFeedData(req, res, next) {
  res.send({
    message: 'This is the raw controller for batchCreateGroupFeedData'
  });
};