'use strict'

module.exports.helpPrivacy = function helpPrivacy(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpPrivacy'
  });
};

module.exports.helpPrivacyJsonPARAMETERS = function helpPrivacyJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for helpPrivacyJsonPARAMETERS'
  });
};