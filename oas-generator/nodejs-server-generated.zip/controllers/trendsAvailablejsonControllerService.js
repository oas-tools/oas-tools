'use strict'

module.exports.trendsAvailable = function trendsAvailable(req, res, next) {
  res.send({
    message: 'This is the raw controller for trendsAvailable'
  });
};

module.exports.trendsAvailableJsonPARAMETERS = function trendsAvailableJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for trendsAvailableJsonPARAMETERS'
  });
};