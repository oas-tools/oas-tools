'use strict'

module.exports.listsMembersDestroy_allJsonPARAMETERS = function listsMembersDestroy_allJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersDestroy_allJsonPARAMETERS'
  });
};

module.exports.listsMembersDestroy_all = function listsMembersDestroy_all(req, res, next) {
  res.send({
    message: 'This is the raw controller for listsMembersDestroy_all'
  });
};