'use strict'

module.exports.allGroupFeeds = function allGroupFeeds(req, res, next) {
  res.send({
    message: 'This is the raw controller for allGroupFeeds'
  });
};

module.exports.createGroupFeed = function createGroupFeed(req, res, next) {
  res.send({
    message: 'This is the raw controller for createGroupFeed'
  });
};