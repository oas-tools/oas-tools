'use strict'

module.exports.blocksCreateJsonPARAMETERS = function blocksCreateJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for blocksCreateJsonPARAMETERS'
  });
};

module.exports.blocksCreate = function blocksCreate(req, res, next) {
  res.send({
    message: 'This is the raw controller for blocksCreate'
  });
};