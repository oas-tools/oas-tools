'use strict'

module.exports.usersSuggestions = function usersSuggestions(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSuggestions'
  });
};

module.exports.usersSuggestionsJsonPARAMETERS = function usersSuggestionsJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for usersSuggestionsJsonPARAMETERS'
  });
};