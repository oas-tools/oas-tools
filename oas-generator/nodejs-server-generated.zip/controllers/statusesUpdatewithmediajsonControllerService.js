'use strict'

module.exports.statusesUpdate_with_mediaJsonPARAMETERS = function statusesUpdate_with_mediaJsonPARAMETERS(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesUpdate_with_mediaJsonPARAMETERS'
  });
};

module.exports.statusesUpdate_with_media = function statusesUpdate_with_media(req, res, next) {
  res.send({
    message: 'This is the raw controller for statusesUpdate_with_media'
  });
};